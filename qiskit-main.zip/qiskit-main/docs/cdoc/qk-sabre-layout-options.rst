====================
QkSabreLayoutOptions
====================

When running the ``qk_transpiler_pass_standalone_sabre_layout`` function this type defines the options for running the pass.

Data Types
==========

.. doxygenstruct:: QkSabreLayoutOptions
   :members:

Functions
=========

.. doxygengroup:: QkSabreLayoutOptions
   :members:
   :content-only:
