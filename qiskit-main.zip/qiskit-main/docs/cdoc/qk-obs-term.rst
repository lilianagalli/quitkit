=========
QkObsTerm
=========

This is a group of functions for interacting with an opaque (Rust-space)
SparseTerm instance.

----------
Data types
----------

.. doxygenstruct:: QkObsTerm
   :members:
   :undoc-members:


---------
Functions
---------

.. doxygengroup:: QkObsTerm
   :content-only:
