.. _qiskit-circuit-library:

.. automodule:: qiskit.circuit.library
   :no-members:
   :no-inherited-members:
   :no-special-members:
