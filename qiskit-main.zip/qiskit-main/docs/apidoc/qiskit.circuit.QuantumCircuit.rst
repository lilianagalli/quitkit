.. _qiskit-circuit-quantumcircuit:

==============================
:class:`.QuantumCircuit` class
==============================

..
   This is so big it gets its own page in the toctree, and because we
   don't want it to use autosummary.

.. currentmodule:: qiskit.circuit

.. autoclass:: qiskit.circuit.QuantumCircuit
   :no-members:
   :no-inherited-members:
   :no-special-members:
   :class-doc-from: class
