.. _qiskit-qasm2:

.. automodule:: qiskit.qasm2
   :no-members:
   :no-inherited-members:
   :no-special-members:
