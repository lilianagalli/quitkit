.. _qiskit-providers-fakeprovider:

.. automodule:: qiskit.providers.fake_provider
   :no-members:
   :no-inherited-members:
   :no-special-members:
