.. _qiskit-transpiler-preset_passmanagers:

.. automodule:: qiskit.transpiler.preset_passmanagers
   :no-members:
   :no-inherited-members:
   :no-special-members:
