.. _qiskit-circuit-annotation:

.. automodule:: qiskit.circuit.annotation
   :no-members:
   :no-inherited-members:
   :no-special-members:
