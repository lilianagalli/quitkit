.. _qiskit-transpiler-plugins:

.. automodule:: qiskit.transpiler.preset_passmanagers.plugin
   :no-members:
   :no-inherited-members:
   :no-special-members:
