.. _qiskit-synthesis:

.. automodule:: qiskit.synthesis
   :no-members:
   :no-inherited-members:
   :no-special-members:
