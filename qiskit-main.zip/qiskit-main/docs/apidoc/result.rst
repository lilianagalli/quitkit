.. _qiskit-result:

.. automodule:: qiskit.result
   :no-members:
   :no-inherited-members:
   :no-special-members:
