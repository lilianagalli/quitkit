.. _qiskit-synthesis_unitary_aqc:

.. automodule:: qiskit.synthesis.unitary.aqc
   :no-members:
   :no-inherited-members:
   :no-special-members:
