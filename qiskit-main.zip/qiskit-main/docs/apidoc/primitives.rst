.. _qiskit-primitives:

.. automodule:: qiskit.primitives
   :no-members:
   :no-inherited-members:
   :no-special-members:
