.. _qiskit-exceptions:

.. automodule:: qiskit.exceptions
   :no-members:
   :no-inherited-members:
   :no-special-members:
