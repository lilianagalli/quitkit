.. _qiskit-circuit-singleton:

.. automodule:: qiskit.circuit.singleton
   :no-members:
   :no-inherited-members:
   :no-special-members:
