.. _qiskit-transpiler-synthesis-plugins:

.. automodule:: qiskit.transpiler.passes.synthesis.plugin
   :no-members:
   :no-inherited-members:
   :no-special-members: