.. _qiskit-transpiler-passes:

.. automodule:: qiskit.transpiler.passes
   :no-members:
   :no-inherited-members:
   :no-special-members:
