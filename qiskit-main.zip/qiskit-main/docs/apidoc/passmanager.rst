.. _qiskit-passmanager:

.. automodule:: qiskit.passmanager
   :no-members:
   :no-inherited-members:
   :no-special-members:
